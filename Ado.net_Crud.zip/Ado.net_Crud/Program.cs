﻿using System;
using System.Data.SqlClient;
namespace Ado.net_Crud
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conn;
            string connectionString = @"Data source=DipaliNaik;Initial catalog=Employee; Integrated Security=True";
            conn = new SqlConnection(connectionString);
            conn.Open();
            Console.WriteLine("Getting Connection");

            try
            {
                Console.WriteLine("Connection Successfull");
                string ans;

                do
                {
                    Console.WriteLine("Select from the option\n1.Insert\n2.Retrive\n3.Update\n4.Delete");
                    int choice = int.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:

                            //create

                            Console.WriteLine("Enter Emp id:");
                            int Emp_id = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Emp Name:");
                            string Emp_name = Console.ReadLine();
                            Console.WriteLine("Enter Emp Salary:");
                            int Emp_salary = int.Parse(Console.ReadLine());
                            string insertQuery = "Insert into Emp_data(Emp_id,Emp_name,Emp_salary) Values ('" + Emp_id + "','" + Emp_name + "','" + Emp_salary +"')";
                            SqlCommand insertcommand = new SqlCommand(insertQuery, conn);
                            insertcommand.ExecuteNonQuery();
                            Console.WriteLine("Data is successfully inserted to table");
                            break;
                        case 2:
                            //retrive
                            string displayQuery = "Select * from Emp_data";
                            SqlCommand displaycommand = new SqlCommand(displayQuery, conn);
                            SqlDataReader reader = displaycommand.ExecuteReader();
                            while (reader.Read())
                            {
                                Console.WriteLine("id:" + reader.GetValue(0).ToString());
                                Console.WriteLine("name:" + reader.GetValue(1).ToString());
                                Console.WriteLine("salary:" + reader.GetValue(2).ToString());
                            }
                            reader.Close();
                            break;
                        case 3:
                            //update
                            int E_id;
                            int E_salary;
                            Console.WriteLine("Enter EmpId that you want to update:");
                            E_id = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter EmpSalary that you want to update:");
                            E_salary = int.Parse(Console.ReadLine());
                            string updateQuery = "Update Emp_data SET Emp_salary=" + E_id + "where Emp_id=" + E_salary + "";
                            SqlCommand updatecommand = new SqlCommand(updateQuery, conn);
                            updatecommand.ExecuteNonQuery();
                            Console.WriteLine("Data is updated successfully");
                            break;
                        case 4:
                            //Delete
                            int d_id;
                            Console.WriteLine("Enter Emp_ID that you want to delete:");
                            d_id = int.Parse(Console.ReadLine());
                            string deleteQuery = "delete from Emp_data where Emp_id=" + d_id;
                            SqlCommand deletecommand = new SqlCommand(deleteQuery, conn);
                            deletecommand.ExecuteNonQuery();
                            Console.WriteLine("deleted successfully");
                            break;
                        default:
                            Console.WriteLine("Wronh input");
                            break;
                    }
                    Console.WriteLine("Do you want to continue:");
                    ans = Console.ReadLine();
                }
                while (ans != "no");
            }
            catch(Exception e)
            {
                Console.WriteLine("Error:"+e.Message);

            }
            finally
            {
                conn.Close();
            }
            Console.ReadLine();

        }
    }
}
        
